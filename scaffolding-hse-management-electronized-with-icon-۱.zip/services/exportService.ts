
import type { Scaffold, Inspector } from '../types';
import { TagColor } from '../types';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Vazirmatn } from './vazir-font';
import { format, subDays } from 'date-fns-jalali';
import { CHECKLIST_QUESTIONS } from '../constants';


const tagLabels = {
  [TagColor.Green]: 'سبز',
  [TagColor.Yellow]: 'زرد',
  [TagColor.Red]: 'قرمز',
};

// --- EXCEL EXPORT ---
export const exportToExcel = (data: Scaffold[]) => {
  if (data.length === 0) {
    alert('داده‌ای برای خروجی گرفتن وجود ندارد.');
    return;
  }
  const rows = data.map(scaffold => ({
    'واحد': scaffold.unit,
    'موقعیت': scaffold.location,
    'شماره تگ': scaffold.tagNumber,
    'شماره پرمیت': scaffold.permitNumber,
    'تاریخ بازرسی': format(new Date(scaffold.inspectionDate), 'yyyy/MM/dd'),
    'وضعیت تگ': tagLabels[scaffold.tagColor],
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows);
  const headers = Object.keys(rows[0]);
  // Set RTL direction for the sheet
  if (!worksheet['!cols']) worksheet['!cols'] = [];
  worksheet['!cols'] = Array(headers.length).fill({ wch: 20 });
  if (!worksheet['!props']) worksheet['!props'] = {};
  worksheet['!props'].RTL = true;
  
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'گزارش داربست');

  XLSX.writeFile(workbook, 'گزارش_داربست.xlsx');
};

// --- PDF EXPORT ---
export const exportToPdf = (data: Scaffold[]) => {
    if (data.length === 0) {
      alert('داده‌ای برای خروجی گرفتن وجود ندارد.');
      return;
    }
    const doc = new jsPDF();
  
    // Add Vazirmatn font
    doc.addFileToVFS('Vazirmatn-Regular.ttf', Vazirmatn);
    doc.addFont('Vazirmatn-Regular.ttf', 'Vazirmatn', 'normal');
    doc.setFont('Vazirmatn');
  
    const tableColumn = ['وضعیت تگ', 'تاریخ بازرسی', 'شماره پرمیت', 'شماره تگ', 'موقعیت', 'واحد'];
    const tableRows: (string | number)[][] = [];
  
    data.forEach(scaffold => {
      const scaffoldData = [
        tagLabels[scaffold.tagColor],
        format(new Date(scaffold.inspectionDate), 'yyyy/MM/dd'),
        scaffold.permitNumber,
        scaffold.tagNumber,
        scaffold.location,
        scaffold.unit,
      ];
      tableRows.push(scaffoldData);
    });

    const title = 'گزارش داربست‌ها';
    const titleWidth = doc.getStringUnitWidth(title) * doc.getFontSize() / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.getWidth() - titleWidth) / 2;
    doc.text(title, titleX, 15);
  
    (doc as any).autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 20,
      theme: 'grid',
      styles: {
        font: 'Vazirmatn',
        halign: 'right',
        cellPadding: 2,
      },
      headStyles: {
        fillColor: [41, 128, 185],
        textColor: 255,
        fontStyle: 'bold',
      },
    });
  
    doc.save('گزارش_داربست.pdf');
  };

// --- WORD EXPORT (Summary) ---
export const exportToWord = (data: Scaffold[], inspectorName: string) => {
    if (data.length === 0) {
      alert('داده‌ای برای خروجی گرفتن وجود ندارد.');
      return;
    }

    const headers = ['ردیف', 'واحد', 'موقعیت', 'شماره تگ', 'شماره پرمیت', 'تاریخ بازرسی', 'وضعیت تگ'];

    let tableHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>گزارش داربست</title>
        <style>
          body { font-family: 'Times New Roman', serif; direction: rtl; }
          table { border-collapse: collapse; width: 100%; }
          th, td { border: 1px solid black; padding: 8px; text-align: right; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h1>گزارش داربست‌ها</h1>
        <h2>بازرس: ${inspectorName}</h2>
        <table>
          <thead>
            <tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>
          </thead>
          <tbody>
            ${data.map((scaffold, index) => `
              <tr>
                <td>${index + 1}</td>
                <td>${scaffold.unit}</td>
                <td>${scaffold.location}</td>
                <td>${scaffold.tagNumber}</td>
                <td>${scaffold.permitNumber}</td>
                <td>${format(new Date(scaffold.inspectionDate), 'yyyy/MM/dd')}</td>
                <td>${tagLabels[scaffold.tagColor]}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', tableHtml], {
      type: 'application/msword'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'گزارش_داربست.doc';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};

// --- WORD EXPORT (Detailed) ---
export const exportScaffoldDetailsToWord = (scaffold: Scaffold, inspectorName: string) => {
    const statusLabels = {
        yes: 'بله',
        no: 'خیر',
        na: 'مرتبط نیست',
    };

    const checklistHtml = scaffold.checklist && scaffold.checklist.length > 0
        ? scaffold.checklist.map(item => {
            const questionText = CHECKLIST_QUESTIONS[item.questionId - 1] || 'سوال یافت نشد';
            return `
                <tr>
                    <td>${item.questionId}</td>
                    <td>${questionText}</td>
                    <td>${statusLabels[item.status] || ''}</td>
                    <td>${item.description || ''}</td>
                </tr>
            `;
        }).join('')
        : '<tr><td colspan="4">چک‌لیست تکمیل نشده است.</td></tr>';

    const fullHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>گزارش کامل داربست</title>
        <style>
          body { font-family: 'Times New Roman', serif; direction: rtl; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid black; padding: 8px; text-align: right; vertical-align: top; }
          th { background-color: #f2f2f2; }
          .header-table td { font-weight: bold; }
        </style>
      </head>
      <body>
        <h1>گزارش کامل داربست</h1>
        <h2>بازرس: ${inspectorName}</h2>
        
        <h3>اطلاعات پایه</h3>
        <table class="header-table">
          <tr>
            <td>واحد:</td><td>${scaffold.unit}</td>
            <td>موقعیت:</td><td>${scaffold.location}</td>
          </tr>
          <tr>
            <td>شماره تگ:</td><td>${scaffold.tagNumber}</td>
            <td>شماره پرمیت:</td><td>${scaffold.permitNumber}</td>
          </tr>
          <tr>
            <td>تاریخ بازرسی:</td><td>${format(new Date(scaffold.inspectionDate), 'yyyy/MM/dd')}</td>
            <td>وضعیت تگ:</td><td>${tagLabels[scaffold.tagColor]}</td>
          </tr>
        </table>

        <h3>چک‌لیست بازرسی</h3>
        <table>
          <thead>
            <tr>
              <th style="width: 5%;">ردیف</th>
              <th style="width: 55%;">سوال</th>
              <th style="width: 15%;">وضعیت</th>
              <th style="width: 25%;">توضیحات</th>
            </tr>
          </thead>
          <tbody>
            ${checklistHtml}
          </tbody>
        </table>
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', fullHtml], {
        type: 'application/msword'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `گزارش_کامل_${scaffold.tagNumber}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};


// --- PRINT FUNCTIONALITY ---
export const printTable = () => {
    window.print();
};


// --- WORD EXPORT (All Inspectors for Admin) ---
export const exportAllScaffoldsToWord = (allScaffolds: Scaffold[], allInspectors: Inspector[], period: 'weekly' | 'monthly') => {
    const now = new Date();
    const startDate = period === 'weekly' ? subDays(now, 7) : subDays(now, 30);

    const filteredScaffolds = allScaffolds.filter(s => new Date(s.inspectionDate) >= startDate);

    if (filteredScaffolds.length === 0) {
        alert(`در بازه زمانی ${period === 'weekly' ? 'هفته' : 'ماه'} گذشته، هیچ داربستی ثبت نشده است.`);
        return;
    }

    const scaffoldsByInspector = filteredScaffolds.reduce((acc, scaffold) => {
        if (!acc[scaffold.inspectorId]) {
            acc[scaffold.inspectorId] = [];
        }
        acc[scaffold.inspectorId].push(scaffold);
        return acc;
    }, {} as Record<string, Scaffold[]>);

    let reportBody = '';
    
    allInspectors.forEach(inspector => {
        const inspectorScaffolds = scaffoldsByInspector[inspector.id];
        if (inspectorScaffolds && inspectorScaffolds.length > 0) {
            reportBody += `<h2>بازرس: ${inspector.name}</h2>`;
            reportBody += `
                <table border="1" style="width:100%; border-collapse: collapse; direction: rtl;">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>واحد</th>
                            <th>موقعیت</th>
                            <th>شماره تگ</th>
                            <th>شماره پرمیت</th>
                            <th>تاریخ بازرسی</th>
                            <th>وضعیت تگ</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${inspectorScaffolds.map((scaffold, index) => `
                            <tr>
                                <td>${index + 1}</td>
                                <td>${scaffold.unit}</td>
                                <td>${scaffold.location}</td>
                                <td>${scaffold.tagNumber}</td>
                                <td>${scaffold.permitNumber}</td>
                                <td>${format(new Date(scaffold.inspectionDate), 'yyyy/MM/dd')}</td>
                                <td>${tagLabels[scaffold.tagColor]}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
    });

    const periodTitle = period === 'weekly' ? 'هفتگی' : 'ماهانه';
    const fullHtml = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset='utf-8'>
        <title>گزارش کلی داربست‌ها</title>
        <style>
          body { font-family: 'Times New Roman', serif; direction: rtl; }
          table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
          th, td { border: 1px solid black; padding: 8px; text-align: right; }
          th { background-color: #f2f2f2; }
        </style>
      </head>
      <body>
        <h1>گزارش کلی داربست‌ها (${periodTitle})</h1>
        ${reportBody}
      </body>
      </html>
    `;

    const blob = new Blob(['\ufeff', fullHtml], {
        type: 'application/msword'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `گزارش_کلی_${periodTitle}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
};
