// electron/preload.js
// Keep this minimal; expose limited, safe APIs if needed via contextBridge later.
