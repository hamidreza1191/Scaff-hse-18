
export type View = 'dashboard' | 'scaffolds' | 'settings' | 'superAdminDashboard';

export enum TagColor {
  Green = 'green',
  Yellow = 'yellow',
  Red = 'red',
}

export type ChecklistStatus = 'yes' | 'no' | 'na';

export interface ChecklistItem {
  questionId: number;
  status: ChecklistStatus;
  description: string;
}

export interface Scaffold {
  id: string;
  unit: string;
  location: string;
  tagNumber: string;
  permitNumber: string;
  inspectionDate: string; // ISO 8601 format
  tagColor: TagColor;
  inspectorId: string;
  checklist?: ChecklistItem[];
}

export interface Inspector {
  id: string;
  name: string;
}

export interface Reminder {
  id: string;
  inspectorId: string;
  targetDateTime: string; // ISO 8601 format
  unit: string;
  tagNumber: string;
  notes: string;
  isCompleted: boolean;
}
